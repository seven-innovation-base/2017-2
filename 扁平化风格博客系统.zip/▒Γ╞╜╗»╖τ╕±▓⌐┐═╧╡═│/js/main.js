
function showTime(){
    var date = new Date(),
        month = date.getMonth() + 1,
        strDate = date.getDate(),
        hour = date.getHours(),
        minute = date.getMinutes(),
        second = date.getSeconds();
    var currentdate = date.getFullYear()+"-"+addZero(month)+"-"+addZero(strDate)+" "+addZero(hour)+":"+addZero(minute)+":"+addZero(second);
    return currentdate;
}

function addZero(val){
    if(val >= 0 && val <= 9){
        return val = "0" + val;
    }else{
        return val;
    }
}


'use strict';
var sidebar = $("#sidebar"),
    mask = $(".mask"),
    sidebar_trigger = $("#sidebar_trigger"),
    backTop = $(".back-to-top"),
    close = $(".close_sidebar");

function showSideBar(){
    mask.fadeIn();
    sidebar.css('right',0);
}

function hideSideBar(){
    mask.fadeOut();
    sidebar.css('right',-sidebar.width());
}
sidebar_trigger.on("click",showSideBar);
close.on("click",hideSideBar);
mask.on("click",hideSideBar);

backTop.on("click",function(){
    $("html, body").animate({
        scrollTop: 0
    }, 600);
});

$(window).on("scroll",function(){
    // 如果已滚动的部分高于窗口的高度
    if($(window).scrollTop() > 0){
        backTop.fadeIn();   // 显示返回按钮
    }else{
        backTop.fadeOut();  // 隐藏返回按钮
    }
});
//浏览器刷新触发scroll事件
$(window).trigger("scroll");


/*登录注册*/

$('#js-signin-btn').on("click",function(){
    active($(".rl-moal .modal-header .nav-tabs li:first"));
    active($(".rl-moal .modal-body .tab-pane:first"));
});
$('#js-signup-btn').on("click",function(){
    active($(".rl-moal .modal-header .nav-tabs li:last"));
    active($(".rl-moal .modal-body .tab-pane:last"));
});
function active(ti){
    return ti.addClass("active").siblings().removeClass("active");
}

// 判断中文字符，以及计算字符长度
function isCn(value){
    var userNameLen = value.length;
    var cnRegexp = /[^\x00-\x80]/g;       //判断一个双字节的中文字符
    if(cnRegexp.test(value)){
        var cnChar = value.match(cnRegexp);    //利用match方法检索出中文字符并返回一个存放中文的数组
        var chineseLen = cnChar.length;         //算出实际的中文字符长度
        userNameLen += chineseLen;
    }
    return userNameLen;
}

function regName($dom){
    var ti = $dom;
    var len = isCn($dom.val());
    if(len==0){
        ti.css("border-color","#ed4933");
        ti.next().text("请输入用户名");
    }else if(/\s+/g.test(ti.val())){
        ti.css("border-color","#ed4933");
        ti.next().text("用户名不能含有空格");
    }else if(len<4 || len>16){
        ti.css("border-color","#ed4933");
        ti.next().text("长度只能在4-16个字符之间");
    }else{
        ti.css("border-color","#ddd");
        ti.next().text("");
        return true;
    }
}


function regPassword($dom){
    var ti = $dom;
    var len = ti.val().length;
    if(len==0){
        ti.css("border-color","#ed4933");
        ti.next().text("请输入密码");
    }else if(/\s+/g.test(ti.val())){
        ti.css("border-color","#ed4933");
        ti.next().text("密码不能含有空格");
    }else if(len<4 || len>16){
        ti.css("border-color","#ed4933");
        ti.next().text("长度只能在4-20个字符之间");
    }else{
        ti.css("border-color","#ddd");
        ti.next().text("");
        return true;
    }
}


function regPwdRepeat($dom,$repeatdom){
    var ti = $dom;
    var len = ti.val().length;
    if(len==0){
        ti.css("border-color","#ed4933");
        ti.next().text("请输入密码");
    }else if(ti.val() != $repeatdom.val()){
        ti.css("border-color","#ed4933");
        ti.next().text("两次密码输入不一致");
    }else{
        ti.css("border-color","#ddd");
        ti.next().text("");
        return true;
    }
}


function regEmail($dom){
    var ti = $dom;
    var len = ti.val().length;
    var emailRegex = /^\w+@\w+\.(net|com|cn|org|so)$/g;
    if(len===0){
        ti.css("border-color","#ed4933");
        ti.next().text("请输入邮箱");
    }else if(!emailRegex.test(ti.val())){
        ti.css("border-color","#ed4933");
        ti.next().text("邮箱格式错误");
    }else{
        ti.css("border-color","#ddd");
        ti.next().text("");
        return true;
    }
}

// function regEmail(){
//     var ti = $("#reg-email");
//     var len = ti.val().length;
//     var emailRegex = /^\w+@\w+\.(net|com|cn|org|so)$/g;
//     var phoneRegex = /^1\d{10}$/;
//     if(len===0){
//         ti.css("border-color","#ed4933");
//         ti.next().text("请输入邮箱或手机号");
//     }else if(!emailRegex.test(ti.val()) && !phoneRegex.test(ti.val())){
//         ti.css("border-color","#ed4933");
//         ti.next().text("邮箱或手机格式错误");
//     }else if(emailRegex.test(ti.val())){
//         // 邮箱验证通过
//     }else if(phoneRegex.test(ti.val())){
//         // 手机验证通过
//     }else{
//         ti.css("border-color","#ddd");
//         ti.next().text("");
//         return true;
//     }
// }

$("#reg-userName").blur(function(){
    regName($(this));
});
$("#reg-password").blur(function(){
    regPassword($(this));
});
$("#reg-pwdRepeat").blur(function(){
    regPwdRepeat($(this),$("#reg-password"));
});
$("#reg-email").blur(function(){
    regPhone($(this));
});

$("#registerWrap input").focus(function(){
    $(this).css("border-color","#ddd");
});

$("#signup-btn").on("click",function(){
    if(regName($("#reg-userName"))){
        if(regPassword($("#reg-password"))){
            if(regPwdRepeat($("#reg-pwdRepeat"),$("#reg-password"))){
                if(regEmail($("#reg-email"))){
                    alert("注册成功！");
                }
            }
        }
    }
});

