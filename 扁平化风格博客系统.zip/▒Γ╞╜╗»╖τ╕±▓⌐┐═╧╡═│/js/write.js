
$("#js-tags .for-choice").on("click",function(){
    var len = $("#js-tags .for-choice.active").length;
    if(len<3){
        $(this).toggleClass("active");
    }else{
        $(this).removeClass("active");
    }
    len = $("#js-tags .for-choice.active").length;
    for(var i=0; i<len; i++){
        var tagName = $("#js-tags .for-choice.active")[i].innerHTML;
        console.log(tagName);
    }
});
