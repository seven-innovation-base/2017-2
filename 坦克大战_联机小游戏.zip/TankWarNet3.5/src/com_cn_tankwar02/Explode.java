package com_cn_tankwar02;

import java.awt.Color;
import java.awt.Graphics;

public class Explode {
	int x;
	int y;
	int []dimeter={1,4,15,31,25,11};
	int step=0;
	GameFrame tc;
	boolean live;

	public boolean isLive() {
		return live;
	}
	public void setLive(boolean live) {
		this.live = live;
	}
	public Explode(int x, int y,boolean live,GameFrame tc ) {
		this.x = x;
		this.y = y;
		this.live=live;
		this.tc=tc;
	}
	public void draw(Graphics g){
		if(!this.isLive())return ;
		if(this.step==this.dimeter.length){
			this.step=0;
			this.setLive(false);
			return ;
		}
		
		Color c=g.getColor();
		g.setColor(Color.orange);
		g.fillOval(x-dimeter[step]/2, y-dimeter[step]/2, dimeter[step], dimeter[step++]);
		g.setColor(c);
	}
	
	
}
