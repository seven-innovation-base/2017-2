package com_cn_tankwar02;

public class ConStant {
	public static final int GAME_FRAME_WIDTH=800;
	public static final int GAME_FRAME_HEIGHT=600;
	public static final int TANK_SPEED=5;
	public static final int TANK_UNIT=30;
	public static final int BULLET_UNIT=10;
	public static final int TCP_PORT=8080;
	public static final int UDP_PORT=2230;
	public static final int SERVER_UDP_PORT=3333;
	public static final int MSG_NEW_TANK=1;
	public static final int MSG_MOVE_TANK=2;
	public static final int MSG_DEAD_TANK=4;
	public static final int MSG_DEAD_BULLET=5;
	public static final int MSG_BULLET=3;
	public static final String TCP_IP="127.0.0.1";
}
