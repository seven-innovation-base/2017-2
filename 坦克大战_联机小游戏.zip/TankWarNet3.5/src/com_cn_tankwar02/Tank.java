package com_cn_tankwar02;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.Random;


public class Tank {
	public  int x,y;
	public int oldX,oldY;
	private boolean bL=false,bU=false,bR=false,bD=false;
	public Dir dir;
	public Dir ptDir=Dir.D;
	public boolean good;
	private boolean live=true;
	private int step=r.nextInt(20)+5;
	private int randomNum=0;
	private int Interval_bullet=5;
	public int id=0;
	

	private static Random r=new Random();
	
	public boolean isLive() {
		return live;
	}

	public void setLive(boolean live) {
		this.live = live;
	}

	//
	GameFrame tc;

	public Tank(int x, int y, boolean good, GameFrame tc) {
		this(x, y, tc);
		this.good = good;
	}
	
	public Tank(int x, int y, GameFrame tc) {
		super();
		this.x = x;
		this.y = y;
		this.oldX=x;
		this.oldY=y;
		this.tc = tc;
		dir=Dir.D;
	}
	public void draw(Graphics g){
		Color c=g.getColor();
		if(this.good)g.setColor(Color.RED);
		else g.setColor(Color.BLUE);
		if(this.isLive()){
			g.fillOval(x, y, ConStant.TANK_UNIT, ConStant.TANK_UNIT);
			g.drawString("id is : "+this.id, x, y-10);
		}
		g.setColor(c);
		if(this.isLive())
			this.Loc_Pt_Dir(g);
		this.Judge_Dir();
	}
	public void Judge_Dir(){
		Dir olddir=this.dir;
		if(!this.bD && !this.bL && !this.bR && !this.bU)this.dir=Dir.STOP;
		else if(!this.bD && this.bL && !this.bR && !this.bU)this.dir=Dir.L;
		else if(!this.bD && this.bL && !this.bR && this.bU)this.dir=Dir.LU;
		else if(!this.bD && !this.bL && !this.bR && this.bU)this.dir=Dir.U;
		else if(!this.bD && !this.bL && this.bR && this.bU)this.dir=Dir.RU;
		else if(!this.bD && !this.bL && this.bR && !this.bU)this.dir=Dir.R;
		else if(this.bD && !this.bL && this.bR && !this.bU)this.dir=Dir.RD;
		else if(this.bD && !this.bL && !this.bR && !this.bU)this.dir=Dir.D;
		else if(this.bD && this.bL && !this.bR && !this.bU)this.dir=Dir.LD;
		this.Location_Dir();
		
		if(olddir!=this.dir){
			Msg msg=new TankMoveMsg(this,this.tc);
			this.tc.nc.send(msg);
		}
		if(this.dir!=Dir.STOP){
			this.ptDir=this.dir;
		}
	}
	public void Location_Dir(){
		/*if(!this.good){
			Dir[] dirs=this.dir.values();
			if(0==this.step){
				this.step=this.r.nextInt(20)+3;
				this.randomNum=r.nextInt(dirs.length);
			}
			this.dir=dirs[randomNum];				
			--this.step;
			if(this.Interval_bullet==0){
				this.fire();
				this.Interval_bullet=5;
			}
			--this.Interval_bullet;
		}*/
		this.oldX=this.x;
		this.oldY=this.y;
		switch(this.dir){
		case L:
			x-=ConStant.TANK_SPEED;
			break;
		case LU:
			x-=ConStant.TANK_SPEED;
			y-=ConStant.TANK_SPEED;
			break;
		case R:
			x+=ConStant.TANK_SPEED;
			break;
		case RU:
			y-=ConStant.TANK_SPEED;
			x+=ConStant.TANK_SPEED;
			break;
		case LD:
			x-=ConStant.TANK_SPEED;
			y+=ConStant.TANK_SPEED;
			break;
		case U:
			y-=ConStant.TANK_SPEED;
			break;
		case RD:
			x+=ConStant.TANK_SPEED;
			y+=ConStant.TANK_SPEED;
			break;
		case D:
			y+=ConStant.TANK_SPEED;
			break;
		}
		
		if(this.x<0)x=0;
		if(this.y<30)this.y=30;
		if(this.x>ConStant.GAME_FRAME_WIDTH-ConStant.TANK_UNIT)this.x=ConStant.GAME_FRAME_WIDTH-ConStant.TANK_UNIT;
		if(this.y>ConStant.GAME_FRAME_HEIGHT-ConStant.TANK_UNIT)this.y=ConStant.GAME_FRAME_HEIGHT-ConStant.TANK_UNIT;
		
	}
	public void Loc_Pt_Dir(Graphics g){
		switch(this.ptDir){
		case L:
			g.drawLine(x, y+ConStant.TANK_UNIT/2, x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT/2);
			break;
		case LU:
			g.drawLine(x, y, x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT/2);
			break;
		case R:
			g.drawLine(x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT/2, x+ConStant.TANK_UNIT, y+ConStant.TANK_UNIT/2);
			break;
		case RU:
			g.drawLine(x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT/2, x+ConStant.TANK_UNIT, y);
			break;
		case LD:
			g.drawLine(x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT/2, x, y+ConStant.TANK_UNIT);
			break;
		case U:
			g.drawLine(x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT/2, x+ConStant.TANK_UNIT/2, y);
			break;
		case RD:
			g.drawLine(x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT/2, x+ConStant.TANK_UNIT, y+ConStant.TANK_UNIT);
			break;
		case D:
			g.drawLine(x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT/2, x+ConStant.TANK_UNIT/2, y+ConStant.TANK_UNIT);
			break;
		}
//		this.hitWall(this.tc.w1);
//		this.hitWall(this.tc.w2);
		//this.crashTank();
	}
	public void move(KeyEvent e){
		
		int keycode=e.getKeyCode();
		switch(keycode){
		
		case KeyEvent.VK_DOWN:
			this.bD=true;
			break;
		case KeyEvent.VK_LEFT:
			this.bL=true;
			break;
		case KeyEvent.VK_UP:
			this.bU=true;
			break;
		case KeyEvent.VK_RIGHT:
			this.bR=true;
			break;
		}
		
	}

	private void fire() {
		int x=this.x+(ConStant.TANK_UNIT/2-ConStant.BULLET_UNIT/2);
		int y=this.y+(ConStant.TANK_UNIT/2-ConStant.BULLET_UNIT/2);
		Bullet b=new Bullet(id,x,y,this.ptDir,this.tc,this.good);
		tc.bullets.add(b);
		Msg msg=new BulletMsg(b);
		this.tc.nc.send(msg);
		
	}

	public boolean isGood() {
		return good;
	}

	public void keReleased(KeyEvent e) {
		
		int keycode=e.getKeyCode();
		switch(keycode){
		case KeyEvent.VK_CONTROL:
			if(this.isLive())
				this.superFire();
			break;
		case KeyEvent.VK_DOWN:
			this.bD=false;
			break;
		case KeyEvent.VK_LEFT:
			this.bL=false;
			break;
		case KeyEvent.VK_UP:
			this.bU=false;
			break;
		case KeyEvent.VK_RIGHT:
			this.bR=false;
			break;
		}
		this.Judge_Dir();
	}

	public Rectangle getRect() {
		return new Rectangle(this.x,this.y,ConStant.TANK_UNIT,ConStant.TANK_UNIT);
	}
	public void back(){
		this.x=this.oldX;
		this.y=this.oldY;
	}
	public void hitWall(Wall w){
		if(this.getRect().intersects(w.getRectAngle())){
			this.back();
		}
	}
	
//	public void crashTank(){
//		for(int i=0;i<this.tc.enemyTanks.size();++i){
//			if(this!=this.tc.enemyTanks.get(i)){
//				if(this.getRect().intersects(this.tc.enemyTanks.get(i).getRect())){
//					this.back();
//				}
//			}
//		}
//		if(this!=this.tc.myTank){
//			if(this.getRect().intersects(this.tc.myTank.getRect())){
//				this.back();
//			}
//		}
//	}
	
	public void superFire(){
		Dir[] dirs=this.dir.values();
		for(int i=1;i<dirs.length;++i){
			this.ptDir=dirs[i];
			this.fire();
		}
	}

	
}
