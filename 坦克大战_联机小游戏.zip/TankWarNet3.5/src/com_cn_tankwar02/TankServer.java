package com_cn_tankwar02;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

public class TankServer {
	List<Client> clients=new ArrayList<Client>();
	private int ID=100;
	public void start(){
		new Thread(new UDPThread()).start();
		
		ServerSocket ss=null;
		try {
			ss = new ServerSocket(ConStant.TCP_PORT);
		} catch (IOException e) {
			e.printStackTrace();
		}
		while(true){  
			Socket s=null;
			try {
				s = ss.accept();
				String ip=s.getInetAddress().getHostAddress();
				DataInputStream dis=new DataInputStream(s.getInputStream());
				
				int port=dis.readInt();
				DataOutputStream dos=new DataOutputStream(s.getOutputStream());
				dos.writeInt(ID++);
				Client c=new Client(ip,port);
				clients.add(c);
				System.out.println("A client have connected!");
			} catch (IOException e) {
				e.printStackTrace();
			} finally{
				if(s!=null){
					try {
						s.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		new TankServer().start();
	}
	
	class Client{
		String IP;
		int port;
		public Client(String iP, int port) {
			IP = iP;
			this.port = port;
		}
	}
	
	class UDPThread implements Runnable{
		byte[]buf=new byte[1024];
		@Override
		public void run() {
			DatagramSocket ds=null;
			try {
				ds=new DatagramSocket(ConStant.SERVER_UDP_PORT);
			} catch (SocketException e) {
				e.printStackTrace();
			}
System.out.println("UDPTHREAD has start!");
			while(ds!=null){
				DatagramPacket dp=null;
				dp=new DatagramPacket(buf,0,buf.length);
				try {
					ds.receive(dp);
					for(int i=0;i<clients.size();++i){
						Client c=clients.get(i);
						dp.setSocketAddress(new InetSocketAddress(c.IP, c.port));
						ds.send(dp);  
System.out.println("A packet has send"+c.port+c.IP);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		}
		
	}
}