package com_cn_tankwar02;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

public class Tank_Dead_Msg implements Msg {
	GameFrame tc;
	public int id;
	public Tank_Dead_Msg(GameFrame tc) {
		this.tc = tc;
	}
	public Tank_Dead_Msg(int id) {
		this.id = id;
	}
	@Override
	public void parse(DataInputStream dis) {
		try {
			int id=dis.readInt();
			if(id==this.tc.myTank.id){
				return ;
			}
			if(this.tc.myTank.id==id){
				this.tc.myTank.setLive(false);
				return ;
			}
			for(int i=0;i<this.tc.enemyTanks.size();++i){
				if(this.tc.enemyTanks.get(i).id==id){
					this.tc.enemyTanks.get(i).setLive(false);
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void send(DatagramSocket ds) {
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		DataOutputStream dos=new DataOutputStream(baos);
		try {
			dos.writeInt(ConStant.MSG_DEAD_TANK);
			dos.writeInt(this.id);
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte []buf=baos.toByteArray();
		DatagramPacket dp=null;
		try {
			dp=new DatagramPacket(buf, buf.length, new InetSocketAddress(ConStant.TCP_IP,ConStant.SERVER_UDP_PORT));
			ds.send(dp);
		} catch (SocketException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}
