package com_cn_tankwar02;

import java.awt.Button;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

public class GameFrame extends Frame{
	NetClient nc=new NetClient(this);
	ConnDialog cd;
	//
	public Tank myTank=new Tank(50,50,true,this);
	public List<Tank> enemyTanks=new ArrayList<Tank>();
	public List<Bullet> bullets=new ArrayList<Bullet>();
	public List<Explode> explodes=new ArrayList<Explode>();
	
	/**
	 * ˫������������
	 */
	Image offScreenImage=null;
	@Override
	public void update(Graphics g){
		if(offScreenImage==null){
			offScreenImage=this.createImage(ConStant.GAME_FRAME_WIDTH,ConStant.GAME_FRAME_HEIGHT);
		}
		Graphics gOffScreen=offScreenImage.getGraphics();
		Color c=gOffScreen.getColor();
		gOffScreen.setColor(Color.green);
		gOffScreen.fillRect(0, 0, ConStant.GAME_FRAME_WIDTH,ConStant.GAME_FRAME_HEIGHT);
		gOffScreen.setColor(c);
		paint(gOffScreen);
		g.drawImage(offScreenImage, 0, 0, null);
	}
	
	
	@Override
	public void paint(Graphics g) {
		g.drawString("bullets of count :"+bullets.size(), 20, 50);
		g.drawString("explodes of count :"+explodes.size(), 20, 70);
	//	g.drawString("enemyTanks of count :"+enemyTanks.size(), 20, 90);
	
		
		for(int i=0;i<bullets.size();++i){
			Bullet b=bullets.get(i);
			b.draw(g);
			if(b.Judge_Inter(myTank)){
				Msg msg=new Tank_Dead_Msg(this.myTank.id);
				myTank.setLive(false);
				this.nc.send(msg);
				Msg bmsg=new BulletDeadMsg(b.tankId,b.id);
				this.nc.send(bmsg);
			}
		}
		for(int i=0;i<enemyTanks.size();++i){
			if(enemyTanks.get(i).isLive()){
				Tank enemy=enemyTanks.get(i);
				if(enemy.isLive()){
					enemy.draw(g);
//System.out.println("��ɵ��");					
				}
			}
		}
		for(int i=0;i<explodes.size();++i){
			if(explodes.get(i).isLive()){
				Explode e=explodes.get(i);
				e.draw(g);
			}else{
				explodes.remove(i);
			}
		}
		myTank.draw(g);
	}
//	public void produce_Tank(){
//		for(int i=0;i<10;++i){
//			Tank Etank=new Tank(100+i*50,100,false,this);
//			this.enemyTanks.add(Etank);
//		}
//	}
	/**
	 *���Ӽ��̼���
	 */
	private class KeyMonitor extends KeyAdapter{
		@Override
		public void keyReleased(KeyEvent e) {
//			System.out.println(e.getKeyCode());
//			if(77==e.getKeyCode()){
//				produce_Tank();
//			}
			if(e.getKeyCode()==KeyEvent.VK_C){
				cd.setVisible(true);
			}else{
				myTank.keReleased(e);
			}
			
		}
		@Override
		public void keyPressed(KeyEvent e) {
			myTank.move(e);
		}
	}
	/**
	 * �����ڲ����Ǵ����ػ�
	 */
	private class paint_Thread implements Runnable{
		@Override
		public void run() {
			while(true){
				repaint();
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} 
		
	}
	public void lunchFrame(){
		
		cd=new ConnDialog(this);
		
		this.setSize(ConStant.GAME_FRAME_WIDTH,ConStant.GAME_FRAME_HEIGHT);
		this.setLocation(100,100);
		
		this.addKeyListener(new KeyMonitor()); 
		
		new Thread(new paint_Thread()).start();
		
	//	nc.connect(ConStant.TCP_IP, ConStant.TCP_PORT);
	//	this.produce_Tank();
		
		this.setVisible(true);
		this.setResizable(false);
		this.setBackground(Color.green );
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	public static void main(String[] args) {
		GameFrame tc=new GameFrame();
		tc.lunchFrame();
	}
	
	class ConnDialog extends Dialog{
		Button b=new Button("ȷ��");
		TextField tfIP=new TextField("127.0.0.1",12);
		TextField tfTCP=new TextField(""+ConStant.TCP_PORT,4);
		TextField tfUDP=new TextField("2222",4);
		public ConnDialog(GameFrame tc) {
			super(tc);
			this.setLocation(300, 300);
			this.setLayout(new FlowLayout());
			this.setTitle("���ӷ����� ");
			this.add(new Label("IP"));
			this.add(tfIP);
			this.add(new Label("TCP_port"));
			this.add(tfTCP);
			this.add(new Label("My_UDP_port"));
			this.add(tfUDP);
			this.add(b);
			this.pack();
			addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent e) {
					setVisible(false);
				}
			});
			b.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					String IP=tfIP.getText().trim();
					int tcpPort=Integer.parseInt(tfTCP.getText().trim());
					int myUdpPort=Integer.parseInt(tfUDP.getText().trim());
					nc.setUdpPort(myUdpPort);
					nc.connect(IP, tcpPort);
					setVisible(false);
				}
			});
			
		}
		
	}
}
