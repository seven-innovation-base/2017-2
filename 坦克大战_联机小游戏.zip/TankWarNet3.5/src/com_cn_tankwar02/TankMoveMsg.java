package com_cn_tankwar02;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

public class TankMoveMsg implements Msg{
	private int id;
	private Dir dir;
	private Tank tank;
	private GameFrame tc;
	public TankMoveMsg(Tank tank,GameFrame tc) {
		this.tank=tank;
		this.tc=tc;
	}

	@Override
	public void parse(DataInputStream dis) {
		try {
			int id=dis.readInt();
			int x=dis.readInt();
			int y=dis.readInt();
			Dir dir=this.dir.values()[dis.readInt()];
			for(int i=0;i<this.tc.enemyTanks.size();++i){
				Tank t=this.tc.enemyTanks.get(i);
				if(id==t.id){
					t.dir=dir;
					t.x=x;
					t.y=y;
					break;
				}
			}
		} catch (IOException e) {
		e.printStackTrace();
		}
		
	}

	@Override
	public void send(DatagramSocket ds) {
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		DataOutputStream dos=new DataOutputStream(baos);
		try {
			dos.writeInt(ConStant.MSG_MOVE_TANK);
			dos.writeInt(this.tank.id);
			dos.writeInt(this.tank.x);
			dos.writeInt(this.tank.y);
			dos.writeInt(this.tank.dir.ordinal());
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte []buf=baos.toByteArray();
		DatagramPacket dp=null;
		try {
			dp=new DatagramPacket(buf, buf.length, new InetSocketAddress(ConStant.TCP_IP,ConStant.SERVER_UDP_PORT));
			ds.send(dp);
		} catch (SocketException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
	}

}
