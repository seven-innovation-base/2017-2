package com_cn_tankwar02;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

import com_cn_tankwar02.TankServer.Client;

public class TankNewMsg implements Msg{
	public Tank tank;
	GameFrame tc;
	public TankNewMsg(Tank tank,GameFrame tc) {
		this.tank = tank;
		this.tc=tc;
	}

	public TankNewMsg() {
	}

	public void send(DatagramSocket ds) {
		
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		DataOutputStream dos=new DataOutputStream(baos);
		try {
			dos.writeInt(ConStant.MSG_NEW_TANK);
			dos.writeInt(this.tank.id);
			dos.writeInt(this.tank.x);
			dos.writeInt(this.tank.y);
			dos.writeInt(this.tank.dir.ordinal());
			dos.writeBoolean(this.tank.good);
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte []buf=baos.toByteArray();
		DatagramPacket dp=null;
		try {
			dp=new DatagramPacket(buf, buf.length, new InetSocketAddress(ConStant.TCP_IP,ConStant.SERVER_UDP_PORT));
			ds.send(dp);
		} catch (SocketException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
	}



	public void parse(DataInputStream dis) {
		try {
			int id=dis.readInt();
			if(id==this.tank.id){
				return ;
			}
			int x=dis.readInt();
			int y=dis.readInt();
			boolean exist=false;
			Dir dir=Dir.values()[dis.readInt()];
			boolean good=dis.readBoolean();
			for(int i=0;i<this.tc.enemyTanks.size();++i){
				if(this.tc.enemyTanks.get(i).id==id){
					exist=true;
					break;
				}
			}
			if(!exist){
				Msg msg=new TankNewMsg(this.tank,this.tc);
				this.tc.nc.send(msg);
				Tank tank=new Tank(x,y,good,tc);
				tank.id=id;
				this.tc.enemyTanks.add(tank);
//System.out.println("id is : "+id+" x: "+x+" y: "+y+"dir is "+dir+" good "+good);
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
