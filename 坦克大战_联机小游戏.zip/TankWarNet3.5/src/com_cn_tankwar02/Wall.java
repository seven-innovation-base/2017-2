package com_cn_tankwar02;

import java.awt.Graphics;
import java.awt.Rectangle;

public class Wall {
	int x;
	int y;
	int w;
	int h;
	GameFrame tc;
	
	public Wall(int x, int y, int w, int h, GameFrame tc) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.tc = tc;
	}
	public void Draw(Graphics g){
		g.fillRect(x, y, w, h);
	}
	
	public Rectangle getRectAngle(){
		return new Rectangle(x,y,w,h);
	}
	
}
