package com_cn_tankwar02;

public enum Dir {
	STOP,L,LU,U,RU,R,RD,D,LD
}
