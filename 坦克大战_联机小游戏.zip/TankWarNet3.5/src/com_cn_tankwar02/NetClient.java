package com_cn_tankwar02;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

public class NetClient {
	private int udpPort;
	public int getUdpPort() {
		return udpPort;
	}



	public void setUdpPort(int udpPort) {
		this.udpPort = udpPort;
	}

	private GameFrame tc;
	public DatagramSocket ds;
	public NetClient(GameFrame tc) {
		this.tc=tc;
	}



	public void connect(String IP,int port){
		try {
			ds=new DatagramSocket(this.udpPort);
		} catch (SocketException e) {
			e.printStackTrace();
		}
		
		Socket s=null;
		try {
			s=new Socket(ConStant.TCP_IP,ConStant.TCP_PORT);
			DataOutputStream dos=new DataOutputStream(s.getOutputStream());
			dos.writeInt(udpPort);
			DataInputStream dis=new DataInputStream(s.getInputStream());
			int id=dis.readInt();
			this.tc.myTank.id=id;
			if(id%2==0){
				this.tc.myTank.good=true;
			}else{
				this.tc.myTank.good=false;				
			}
//System.out.println("i have connected server and udpPort is : "
	//		+udpPort+" server give me a id is: "+id);		
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			if(s!=null){
				try {
					s.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		TankNewMsg msg=new TankNewMsg(this.tc.myTank,this.tc);
		send(msg);
		
		new Thread(new UDPReceived()).start();
	}



	public  void send(Msg msg) {
		if(ds!=null){
			msg.send(ds);
		}
	}
	
	class UDPReceived implements Runnable{
		byte[] buf=new byte[1024];
		@Override
		public void run() {
			while(true){
				ByteArrayInputStream bais=new ByteArrayInputStream(buf);
				DataInputStream dis=new DataInputStream(bais);
				DatagramPacket dp=new DatagramPacket(buf, buf.length);
				try {
					ds.receive(dp);
					parse(dp);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		private void parse(DatagramPacket dp) {
			ByteArrayInputStream bais=new ByteArrayInputStream(buf,0,dp.getLength());
			DataInputStream dis=new DataInputStream(bais);
			int msgType=0;
			Msg msg=null;
			try {
				msgType=dis.readInt();
			} catch (IOException e) {
				e.printStackTrace();
			}
			switch(msgType){
			case ConStant.MSG_NEW_TANK:
				msg=new TankNewMsg(tc.myTank,tc);
				msg.parse(dis);
				break;
			case ConStant.MSG_MOVE_TANK:
				msg=new TankMoveMsg(tc.myTank,tc);
				msg.parse(dis);
				break;
			case ConStant.MSG_BULLET:
				msg=new BulletMsg(tc);
				msg.parse(dis);
				break;
			case ConStant.MSG_DEAD_BULLET:
				msg=new BulletDeadMsg(tc);
				msg.parse(dis);
				break;
			case ConStant.MSG_DEAD_TANK:
				msg=new Tank_Dead_Msg(tc);
//System.out.println("msg=new Tank_Dead_Msg(tc);");				
				msg.parse(dis);
				break;
			}
		}
		
	}
}
