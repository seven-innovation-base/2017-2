package com_cn_tankwar02;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

public class BulletMsg implements Msg {
	Bullet b;
	GameFrame tc;
	
	public BulletMsg(Bullet b) {
		super();
		this.b = b;
	}
	
	public BulletMsg(GameFrame tc) {
		super();
		this.tc = tc;
	}


	@Override
	public void send(DatagramSocket ds) {

		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		DataOutputStream dos=new DataOutputStream(baos);
		try {
			dos.writeInt(ConStant.MSG_BULLET);
			dos.writeInt(this.b.tankId);
			dos.writeInt(this.b.id);
			dos.writeInt(this.b.x);
			dos.writeInt(this.b.y);
			dos.writeInt(this.b.dir.ordinal());
			dos.writeBoolean(this.b.good);
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte []buf=baos.toByteArray();
		DatagramPacket dp=null;
		try {
			dp=new DatagramPacket(buf, buf.length, new InetSocketAddress(ConStant.TCP_IP,ConStant.SERVER_UDP_PORT));
			ds.send(dp);
		} catch (SocketException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
	@Override
	public void parse(DataInputStream dis) {
		try {
			int tankid=dis.readInt();
System.out.println(tankid);
			if(tankid==this.tc.myTank.id){
				return ;
			}
			int id=dis.readInt();
			int x=dis.readInt();
			int y=dis.readInt();
			Dir dir=Dir.values()[dis.readInt()];
			boolean good=dis.readBoolean();
			boolean exist=false;
			Bullet bb=new Bullet(id, x, y, dir, tc, good);
			bb.id=id;
			this.tc.bullets.add(bb);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
