package com_cn_tankwar02;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

import org.w3c.dom.css.Rect;


public class Bullet {
	public int x,y;
	Dir dir;
	public static int ID=1;
	private boolean Live=true;
	private GameFrame tc;
	public boolean good;
	public int tankId;
	public int id;
	public boolean isLive() {
		return Live;
	}


	public void setLive(boolean live) {
		Live = live;
	}

	public Bullet(int tankid, int x, int y, Dir dir,GameFrame tc, boolean good) {
		this.tankId=tankid;
		this.x = x;
		this.y = y;
		this.dir = dir;
		this.tc = tc;
		this.good = good;
		this.id=ID++;
	}
	
	public void draw(Graphics g){
		Color c=g.getColor();
		if(this.good){
			g.setColor(Color.white);
		}else{
			g.setColor(Color.BLACK);
		}
		g.fillOval(this.x, this.y, ConStant.BULLET_UNIT, ConStant.BULLET_UNIT);
		g.setColor(c);
//		for(int i=0;i<this.tc.enemyTanks.size();++i){
//			this.Judge_Inter(this.tc.enemyTanks.get(i));
//		}
		this.Judge_Inter(this.tc.myTank);
		
		move();
	}

	private void move() {
		switch(this.dir){
		case L:
			x-=4*ConStant.TANK_SPEED;
			break;
		case LU:
			x-=4*ConStant.TANK_SPEED;
			y-=4*ConStant.TANK_SPEED;
			break;
		case R:
			x+=4*ConStant.TANK_SPEED;
			break;
		case RU:
			y-=4*ConStant.TANK_SPEED;
			x+=4*ConStant.TANK_SPEED;
			break;
		case LD:
			x-=4*ConStant.TANK_SPEED;
			y+=4*ConStant.TANK_SPEED;
			break;
		case U:
			y-=4*ConStant.TANK_SPEED;
			break;
		case RD:
			x+=4*ConStant.TANK_SPEED;
			y+=4*ConStant.TANK_SPEED;
			break;
		case D:
			y+=4*ConStant.TANK_SPEED;
			break;
		}
		if(this.x<0 || this.y<0 || this.x>ConStant.GAME_FRAME_WIDTH ||this.y>ConStant.GAME_FRAME_HEIGHT ){
			this.Live=false;
		}
		this.remove();
	}
	public void remove(){
		if(!this.Live)
			this.tc.bullets.remove(this);
	}
	public Rectangle getRect(){
		return new Rectangle(this.x,this.y,ConStant.BULLET_UNIT,ConStant.BULLET_UNIT);
	}
	public boolean Judge_Inter(Tank t){
		if(this.good!=t.isGood()  &&  this.getRect().intersects(t.getRect()) && t.isLive()){
			t.setLive(false);
			this.setLive(false);
			Explode e=new Explode(this.x,this.y,true,this.tc);
			this.tc.explodes.add(e);
			return true;
	//		tc.enemyTanks.remove(t);
		}
		return false;
		//this.hitWall(this.tc.w1);
		//this.hitWall(this.tc.w2);
	}
	public void hitWall(Wall w){
		if(this.getRect().intersects(w.getRectAngle())){
			this.setLive(false);
		}
			
	}
	
}
