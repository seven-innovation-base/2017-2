package com_cn_tankwar02;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

public class BulletDeadMsg implements Msg {
	GameFrame tc;
	int tankId;
	int id;
	public BulletDeadMsg(GameFrame tc) {
		super();
		this.tc = tc;
	}

	public BulletDeadMsg(int tankId, int id) {
		super();
		this.tankId = tankId;
		this.id = id;
	}

	@Override
	public void parse(DataInputStream dis) {
		try {
			int tankid=dis.readInt();
			if(tankid==this.tc.myTank.id){
				return ;
			}
			int id=dis.readInt();
			for(int i=0;i<tc.bullets.size();++i){
				if(id==tc.bullets.get(i).id){
System.out.println("tc.bullets.get(i).setLive(false)");
					tc.bullets.get(i).setLive(false);
					break;
				}
			}
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void send(DatagramSocket ds) {
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		DataOutputStream dos=new DataOutputStream(baos);
		try {
			dos.writeInt(ConStant.MSG_DEAD_TANK);
			dos.writeInt(this.tankId);
			dos.writeInt(this.id);
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte []buf=baos.toByteArray();
		DatagramPacket dp=null;
		try {
			dp=new DatagramPacket(buf, buf.length, new InetSocketAddress(ConStant.TCP_IP,ConStant.SERVER_UDP_PORT));
			ds.send(dp);
		} catch (SocketException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

}
