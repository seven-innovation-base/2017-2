package com_cn_tankwar02;

import java.io.DataInputStream;
import java.net.DatagramSocket;

public interface Msg {
	public void send(DatagramSocket ds);
	public void parse(DataInputStream dis);
}
